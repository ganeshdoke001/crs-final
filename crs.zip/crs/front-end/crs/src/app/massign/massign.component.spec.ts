import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MassignComponent } from './massign.component';

describe('MassignComponent', () => {
  let component: MassignComponent;
  let fixture: ComponentFixture<MassignComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MassignComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MassignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
