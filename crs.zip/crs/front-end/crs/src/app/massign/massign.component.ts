import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-massign',
  templateUrl: './massign.component.html',
  styleUrls: ['./massign.component.css']
})
export class MassignComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
