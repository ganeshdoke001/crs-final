import { HttpClient, HttpClientModule, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Customer } from './customer';
import { User } from './user';


@Injectable({
  providedIn: 'root'
})
export class TelecomService {

user:User =new User();
private baseurl="http://localhost:8010/api/customers";
 
  constructor(private http:HttpClient) { }

  // getCustomerList():Observable<Customer[]>{
  //   const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa(this.user.username + ':' + this.user.password) });
  //   return this.httpClient.get<Customer[]>(`${this.baseUrl}`,{headers});
   
  // }

  // public deleteCustomer(customer: { cust_Id: number; }):Observable<Customer> {
    
  //   const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa(this.user.username + ':' + this.user.password) });
  //   return this.httpClient.delete<Customer>(`${this.baseUrl}`+ customer.cust_Id,{headers});
  // }

  // public saveCustomer(customer: any):Observable<Customer>
  // {
  //   const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa(this.user.username + ':' + this.user.password) });
  //   return this.httpClient.post<Customer>(`${this.baseUrl}`, customer,{headers});
  // }
 
  
getcomplaints():Observable<Customer[]>{
  return this.http.get<Customer[]>(`${this.baseurl}`);
}
createCustomer(customer:Customer):Observable<object>{
  return this.http.post(`${this.baseurl}`,customer);
  
}
getCustomerByid(cust_Id: number):Observable<Customer>{
  return this.http.get<Customer>(`${this.baseurl}/${cust_Id}`);
}
updateCustomer(customer:Customer):Observable<Object>{
  return this.http.put(`${this.baseurl}`,customer);
}
deletecustomer(cust_Id:number):Observable<Object>{
return this.http.delete(`${this.baseurl}/${cust_Id}`);

}
}




  
