export class Customer {
    cust_Id!:number;
    pin!:number;
    mobileNo!:number;
    email!:String;
    address!:String;
    complaint!:String;
    status!:String;
    name!:string;
}
