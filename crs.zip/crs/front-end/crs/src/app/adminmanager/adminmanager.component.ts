import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminmanager',
  templateUrl: './adminmanager.component.html',
  styleUrls: ['./adminmanager.component.css']
})
export class AdminmanagerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
