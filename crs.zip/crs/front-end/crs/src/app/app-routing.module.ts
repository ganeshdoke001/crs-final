import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { AddcustomerComponent } from './addcustomer/addcustomer.component';
import { AdmincustomerComponent } from './admincustomer/admincustomer.component';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { AdminengineerComponent } from './adminengineer/adminengineer.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminmanagerComponent } from './adminmanager/adminmanager.component';
import { CustomercomplaintsComponent } from './customercomplaints/customercomplaints.component';
import { CustomerdashboardComponent } from './customerdashboard/customerdashboard.component';
import { CustomerloginComponent } from './customerlogin/customerlogin.component';
import { EngineerdashboardComponent } from './engineerdashboard/engineerdashboard.component';

import { EngineerloginComponent } from './engineerlogin/engineerlogin.component';

import { HomepageComponent } from './homepage/homepage.component';
import { ManagerdashboardComponent } from './managerdashboard/managerdashboard.component';
import { ManagerloginComponent } from './managerlogin/managerlogin.component';
import { MassignComponent } from './massign/massign.component';
import { McustomercomplaintsComponent } from './mcustomercomplaints/mcustomercomplaints.component';
import { MstatusComponent } from './mstatus/mstatus.component';
import { RaisecomplaintComponent } from './raisecomplaint/raisecomplaint.component';
import { RegisterComponent } from './register/register.component';
import { StatusComponent } from './status/status.component';
import { TrackcomplaintComponent } from './trackcomplaint/trackcomplaint.component';
import { UpdatecustomerComponent } from './updatecustomer/updatecustomer.component';
import { UpdatestatusComponent } from './updatestatus/updatestatus.component';
import { ViewcomplaintComponent } from './viewcomplaint/viewcomplaint.component';

const routes: Routes = [
  {path:'',redirectTo:"homepage",pathMatch:"full"},
  
  {path:'customerlogin',component:CustomerloginComponent},
  {path:'homepage',component:HomepageComponent},
  {path:'managerlogin',component:ManagerloginComponent},
  {path:'engineerlogin',component:EngineerloginComponent},
  {path:'adminlogin',component:AdminloginComponent},
  {path:'register',component:RegisterComponent}, 
  {path:'aboutus',component:AboutusComponent},
  {path:'customerdashboard',component:CustomerdashboardComponent},
  {path:'status',component:StatusComponent},
  {path:'viewcomplaint',component:ViewcomplaintComponent},
  {path:'trackcomplaint',component:TrackcomplaintComponent},
  {path:'raisecomplaint',component:RaisecomplaintComponent},
  {path:'managerdashboard',component:ManagerdashboardComponent},
  {path:'admindashboard',component:AdmindashboardComponent},
  {path:'admincustomer',component:AdmincustomerComponent},
  {path:'adminmanager',component:AdminmanagerComponent},
  {path:'adminengineer',component:AdminengineerComponent},
  {path:'engineerdashboard',component:EngineerdashboardComponent},
  {path:'updatestatus',component:UpdatestatusComponent},
  {path:'customercomplaints',component:CustomercomplaintsComponent},
  {path:'mcustomercomplaints',component:McustomercomplaintsComponent},
  {path:'mstatus',component:MstatusComponent},
  {path:'massign',component:MassignComponent},
  {path:'addcustomer',component:AddcustomerComponent},
  {path:'updatecustomer/:cust_Id',component:UpdatecustomerComponent}
 ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
