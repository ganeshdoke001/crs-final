import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginuserService } from '../loginuser.service';

import { User } from '../user';

@Component({
  selector: 'app-customerlogin',
  templateUrl: './customerlogin.component.html',
  styleUrls: ['./customerlogin.component.css']
})
export class CustomerloginComponent implements OnInit {

username:string='';
password:string='';
message:any

user:User =new User();

  constructor(private loginuserservice:LoginuserService,private router:Router)  { }

  ngOnInit(): void {
  }

  userLogin()
 {
  console.log(this.user);
   this.loginuserservice.loginuser(this.user).subscribe(data=>{
     alert("you are succesfully login");
     sessionStorage.setItem('username',this.username);
        return this.user;
    this.router.navigate(['customerdashboard'])
    sessionStorage.setItem('username',this.username);
        return data;
   },error=>{
     alert("please enter corect username and password");
   }
   );
   
      
   }
  
 }


