import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginuserService } from '../loginuser.service';

@Component({
  selector: 'app-engineerlogin',
  templateUrl: './engineerlogin.component.html',
  styleUrls: ['./engineerlogin.component.css']
})
export class EngineerloginComponent implements OnInit {

  constructor(private loginuserservice:LoginuserService,private router:Router) { }

  ngOnInit(): void {
  }

  onLogin(loginForm: NgForm){
    console.log(loginForm.value);
    const user=this.loginuserservice.loginuser(loginForm.value);
    console.log(user);

    if(user){
      localStorage.setItem('user',JSON.stringify(user));
      //console.log('Login Successfully')
      this.router.navigate([''])

    }
    else{
      console.log('Login not Successfully')
    }
  }
  
}
