import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-engineerdashboard',
  templateUrl: './engineerdashboard.component.html',
  styleUrls: ['./engineerdashboard.component.css']
})
export class EngineerdashboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
