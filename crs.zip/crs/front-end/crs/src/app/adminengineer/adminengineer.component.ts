import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adminengineer',
  templateUrl: './adminengineer.component.html',
  styleUrls: ['./adminengineer.component.css']
})
export class AdminengineerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
