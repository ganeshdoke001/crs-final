import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminengineerComponent } from './adminengineer.component';

describe('AdminengineerComponent', () => {
  let component: AdminengineerComponent;
  let fixture: ComponentFixture<AdminengineerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminengineerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminengineerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
