import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Customer } from '../customer';
import { TelecomService } from '../telecom.service';

@Component({
  selector: 'app-updatecustomer',
  templateUrl: './updatecustomer.component.html',
  styleUrls: ['./updatecustomer.component.css']
})
export class UpdatecustomerComponent implements OnInit {

cust_id:number
customer:Customer = new Customer();
  constructor(private telecomservice:TelecomService,
    private route:ActivatedRoute,private router:Router) { }

  ngOnInit(): void {
    
    this.cust_id = this.route.snapshot.params['cust_Id'];
    
    this.telecomservice.getCustomerByid( this.cust_id).subscribe(data =>{
      this.customer = data;
    });
    
  }
onSubmit(){
  this.telecomservice.updateCustomer(this.customer).subscribe(data =>{
this.gotocustomerlist();
  },error => console.log(error));
  
}
gotocustomerlist(){
  this.router.navigate(['/admincustomer'])
}
  }
