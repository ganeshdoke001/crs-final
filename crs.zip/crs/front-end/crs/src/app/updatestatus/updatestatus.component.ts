import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatestatus',
  templateUrl: './updatestatus.component.html',
  styleUrls: ['./updatestatus.component.css']
})
export class UpdatestatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
