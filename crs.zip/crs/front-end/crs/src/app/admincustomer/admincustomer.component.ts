import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { TelecomService } from '../telecom.service';

@Component({
  selector: 'app-admincustomer',
  templateUrl: './admincustomer.component.html',
  styleUrls: ['./admincustomer.component.css']
})
export class AdmincustomerComponent implements OnInit {
cust_Id:any;
  customers:Customer[];

  constructor(private customerservice:TelecomService,
private router:Router){ }
  ngOnInit(): void {
    this.getcomplaints();
  }
   private getcomplaints(){
    this.customerservice.getcomplaints().subscribe((data:Customer[])=>{
      this.customers=data;
    }
    )

  }
  updatecustomer(cust_id:number){
this.router.navigate(['updatecustomer',cust_id]);
  }
  deletecustomer(cust_Id:number){
    this.customerservice.deletecustomer(cust_Id).subscribe( data =>{
      console.log(data);
      this.getcomplaints();
    })
  }
  
  
}
