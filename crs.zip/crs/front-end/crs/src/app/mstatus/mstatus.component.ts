import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { TelecomService } from '../telecom.service';

@Component({
  selector: 'app-mstatus',
  templateUrl: './mstatus.component.html',
  styleUrls: ['./mstatus.component.css']
})
export class MstatusComponent implements OnInit {

  customers:Customer[];
  constructor(private customerservice:TelecomService) { }

  ngOnInit(): void {
    this.customerservice.getcomplaints().subscribe((data:Customer[])=>{
      this.customers=data;
    }
    )

  }
}
