import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MstatusComponent } from './mstatus.component';

describe('MstatusComponent', () => {
  let component: MstatusComponent;
  let fixture: ComponentFixture<MstatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MstatusComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MstatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
