import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-raisecomplaint',
  templateUrl: './raisecomplaint.component.html',
  styleUrls: ['./raisecomplaint.component.css']
})
export class RaisecomplaintComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
