import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { TelecomService } from '../telecom.service';

@Component({
  selector: 'app-addcustomer',
  templateUrl: './addcustomer.component.html',
  styleUrls: ['./addcustomer.component.css']
})
export class AddcustomerComponent implements OnInit {
customer:Customer = new Customer();
  constructor(private  customerservice:TelecomService,private router:Router) { 
    
  }

  ngOnInit(): void {
  }
  saveCustomer(){
    this.customerservice.createCustomer(this.customer).subscribe(data =>{
      console.log(data);
      this.gotocustomerlist();
      
    },
    error=>console.log(error));
  }

  gotocustomerlist(){
    this.router.navigate(['/admincustomer'])
  }
onSubmit(){
  console.log(this.customer);
  this.saveCustomer();

}
}
