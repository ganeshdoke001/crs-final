import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerdashboard',
  templateUrl: './Customerdashboard.component.html',
  styleUrls: ['./customerdashboard.component.css']
})
export class CustomerdashboardComponent implements OnInit {
customer :any;
  
  constructor(private http:HttpClient) { }
 
  ngOnInit(): void {
    let response=this.http.get("http://localhost:8184/c");
    response.subscribe((data: any)=>this.customer=data);
  }

}
