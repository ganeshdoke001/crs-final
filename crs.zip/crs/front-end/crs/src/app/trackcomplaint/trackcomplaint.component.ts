import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trackcomplaint',
  templateUrl: './trackcomplaint.component.html',
  styleUrls: ['./trackcomplaint.component.css']
})
export class TrackcomplaintComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
