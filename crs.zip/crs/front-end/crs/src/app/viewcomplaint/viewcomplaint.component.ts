import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { TelecomService } from '../telecom.service';

@Component({
  selector: 'app-viewcomplaint',
  templateUrl: './viewcomplaint.component.html',
  styleUrls: ['./viewcomplaint.component.css']
})
export class ViewcomplaintComponent implements OnInit {
  customers:Customer[];
  constructor(private customerservice:TelecomService) { }

  ngOnInit(): void {
    this.customerservice.getcomplaints().subscribe((data:Customer[])=>{
      this.customers=data;
    }
    )

  }
}
