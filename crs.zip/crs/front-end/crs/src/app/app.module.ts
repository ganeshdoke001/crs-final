import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { CustomerloginComponent } from './customerlogin/customerlogin.component';
import { ManagerloginComponent } from './managerlogin/managerlogin.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { EngineerloginComponent } from './engineerlogin/engineerlogin.component';
import { RegisterComponent } from './register/register.component';
import { AboutusComponent } from './aboutus/aboutus.component';

import{HttpClientModule} from '@angular/common/http';
import { CustomerdashboardComponent } from './customerdashboard/customerdashboard.component';
import { RaisecomplaintComponent } from './raisecomplaint/raisecomplaint.component';
import { ViewcomplaintComponent } from './viewcomplaint/viewcomplaint.component';
import { TrackcomplaintComponent } from './trackcomplaint/trackcomplaint.component';
import { StatusComponent } from './status/status.component';
import { ManagerdashboardComponent } from './managerdashboard/managerdashboard.component';

import { FormsModule } from '@angular/forms';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { AdmincustomerComponent } from './admincustomer/admincustomer.component';
import { AdminmanagerComponent } from './adminmanager/adminmanager.component';
import { AdminengineerComponent } from './adminengineer/adminengineer.component';
import { EngineerdashboardComponent } from './engineerdashboard/engineerdashboard.component';
import { CustomercomplaintsComponent } from './customercomplaints/customercomplaints.component';
import { UpdatestatusComponent } from './updatestatus/updatestatus.component';
import { McustomercomplaintsComponent } from './mcustomercomplaints/mcustomercomplaints.component';
import { MstatusComponent } from './mstatus/mstatus.component';
import { MassignComponent } from './massign/massign.component';
import { LoginuserService } from './loginuser.service';
import { AddcustomerComponent } from './addcustomer/addcustomer.component';
import { UpdatecustomerComponent } from './updatecustomer/updatecustomer.component';

@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    CustomerloginComponent,
    ManagerloginComponent,
    AdminloginComponent,
    EngineerloginComponent,
    RegisterComponent,
    AboutusComponent,
    CustomerdashboardComponent,
    RaisecomplaintComponent,
    ViewcomplaintComponent,
    TrackcomplaintComponent,
    StatusComponent,
    
    ManagerdashboardComponent,
    AdmindashboardComponent,
    AdmincustomerComponent,
    AdminmanagerComponent,
    AdminengineerComponent,
    EngineerdashboardComponent,
    CustomercomplaintsComponent,
    UpdatestatusComponent,
    McustomercomplaintsComponent,
    MstatusComponent,
    MassignComponent,
    AddcustomerComponent,
    UpdatecustomerComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    
    FormsModule,
    HttpClientModule

  ],
  providers: [LoginuserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
