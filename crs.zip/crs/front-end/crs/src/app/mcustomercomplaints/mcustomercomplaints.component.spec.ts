import { ComponentFixture, TestBed } from '@angular/core/testing';

import { McustomercomplaintsComponent } from './mcustomercomplaints.component';

describe('McustomercomplaintsComponent', () => {
  let component: McustomercomplaintsComponent;
  let fixture: ComponentFixture<McustomercomplaintsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ McustomercomplaintsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(McustomercomplaintsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
