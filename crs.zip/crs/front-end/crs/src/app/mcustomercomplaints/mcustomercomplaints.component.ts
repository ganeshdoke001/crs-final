import { Component, OnInit } from '@angular/core';
import { Customer } from '../customer';
import { TelecomService } from '../telecom.service';

@Component({
  selector: 'app-mcustomercomplaints',
  templateUrl: './mcustomercomplaints.component.html',
  styleUrls: ['./mcustomercomplaints.component.css']
})
export class McustomercomplaintsComponent implements OnInit {

  customers:Customer[];
  constructor(private customerservice:TelecomService) { }

  ngOnInit(): void {
    this.customerservice.getcomplaints().subscribe((data:Customer[])=>{
      this.customers=data;
    }
    )

  }
}
