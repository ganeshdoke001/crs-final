export class User
{
    userId!:number;
    password!:String;
    username!:String;
    role!:String;
    
}
