import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { TelecomService } from '../telecom.service';

@Component({
  selector: 'app-customercomplaints',
  templateUrl: './customercomplaints.component.html',
  styleUrls: ['./customercomplaints.component.css']
})
export class CustomercomplaintsComponent implements OnInit {

  customers:Customer[];
  constructor(private customerservice:TelecomService) { }

  ngOnInit(): void {
    this.customerservice.getcomplaints().subscribe((data:Customer[])=>{
      this.customers=data;
    }
    )

  }
}
