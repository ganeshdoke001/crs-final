import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomercomplaintsComponent } from './customercomplaints.component';

describe('CustomercomplaintsComponent', () => {
  let component: CustomercomplaintsComponent;
  let fixture: ComponentFixture<CustomercomplaintsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomercomplaintsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomercomplaintsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
