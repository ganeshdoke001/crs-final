package com.telecom.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.telecom.exception.ErrorMessage;
import com.telecom.exception.ResourceNotFoundException;
import com.telecom.model.Customer;
import com.telecom.service.Customer_Service;

@RestController
@RequestMapping("/api")
public class Customer_Controller 
{

	@Autowired
	private Customer_Service customer_Service;
	
	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> getCustomers()
	{
		return new ResponseEntity<List<Customer>>(customer_Service.list(),HttpStatus.OK);
	}
	
	@GetMapping("/customers/{cust_Id}")
	public ResponseEntity<Customer> getCustomerByID(@PathVariable("cust_Id") long id)
	{
		return new ResponseEntity<Customer>(customer_Service.getCustomer(id),HttpStatus.OK);
	}
	
	@PostMapping("/customers")
	public ResponseEntity<Customer> saveCustomer( @RequestBody Customer customer)
	{
		return new ResponseEntity<Customer>(customer_Service.save(customer),HttpStatus.CREATED) ;
		
	}
	
	@PutMapping("/customers")
	public ResponseEntity<Customer> updateCustomer(@RequestBody Customer customer)
	{
		return  new ResponseEntity<Customer>(customer_Service.update(customer),HttpStatus.CREATED) ;
		
	}
	
	@DeleteMapping("/customers/{id}")
	public ResponseEntity<?> delete(@PathVariable ("id") long id)
	{
		customer_Service.deleteById(id);
		return new ResponseEntity<String>("Customer is Deleted",HttpStatus.OK);
	}
	
	@ExceptionHandler
	public ResponseEntity<ErrorMessage > handleException(ResourceNotFoundException exc) {
		
		ErrorMessage  error = new ErrorMessage ();
		
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setMessage(exc.getMessage());
		error.setTimeStamp(System.currentTimeMillis());
		
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	 }

	@ExceptionHandler
	public ResponseEntity<ErrorMessage > handleException(Exception exc) {
		
		ErrorMessage  error = new ErrorMessage ();
		
		error.setStatus(HttpStatus.BAD_REQUEST.value());
		error.setMessage(exc.getMessage());
		error.setTimeStamp(System.currentTimeMillis());
		
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}	
}
