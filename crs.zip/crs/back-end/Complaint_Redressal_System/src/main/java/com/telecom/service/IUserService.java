package com.telecom.service;

import java.util.List;
import java.util.Optional;

import com.telecom.model.User;



public interface IUserService {

	
	public List<User> findAllUsers() ;

	public Optional<User> findUserById(int id);
	
	public User findByUserName(String userName) ;
	
	public User deleteUser(int userId);
	
	public  User updateUser(int id,User user);
	 
	public  User saveUser(User newUser);

}
