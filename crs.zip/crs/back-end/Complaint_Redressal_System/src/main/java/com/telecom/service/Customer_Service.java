package com.telecom.service;

import java.util.List;


import com.telecom.model.Customer;

public interface Customer_Service 
{
	public List<Customer> list();
	public void deleteById(long id);
	public Customer getCustomer(long cust_Id);
	public Customer update(Customer customer);
	public Customer save(Customer customer);
}
