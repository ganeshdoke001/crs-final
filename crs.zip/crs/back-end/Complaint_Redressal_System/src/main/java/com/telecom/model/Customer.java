package com.telecom.model;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name="Customer")
public class Customer 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(nullable= false,updatable = false)
	private long cust_Id;
	private String Name ;
	private long pin;
	private long mobileNo;
	private String email;
	private String address;
	private String complaint;
	private String status;
	
	public long getCust_Id() {
		return cust_Id;
	}
	public void setCust_Id(long cust_Id) {
		this.cust_Id = cust_Id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public long getPin() {
		return pin;
	}
	public void setPin(long pin) {
		this.pin = pin;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getComplaint() {
		return complaint;
	}
	public void setComplaint(String complaint) {
		this.complaint = complaint;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Customer(long cust_Id, String name, long pin, long mobileNo, String email, String address, String complaint,
			String status) {
		super();
		this.cust_Id = cust_Id;
		Name = name;
		this.pin = pin;
		this.mobileNo = mobileNo;
		this.email = email;
		this.address = address;
		this.complaint = complaint;
		this.status = status;
	}
	public Customer() {
		super();
	}

}