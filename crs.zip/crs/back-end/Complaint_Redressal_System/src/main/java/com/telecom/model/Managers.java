package com.telecom.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Managers")
public class Managers {
	
	@Id
	@Column(nullable= false,updatable = false)
	private long mgr_id;
	private String name;
	private String username;
	private String password;
	
	@OneToMany
	private List<Customer> customer;
	
	@ManyToMany
	@JoinColumn(name="mgr_id")
	private List<Engineers> engineers;

	public long getMgr_id() {
		return mgr_id;
	}

	public void setMgr_id(long mgr_id) {
		this.mgr_id = mgr_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Customer> getCustomer() {
		return customer;
	}

	public void setCustomer(List<Customer> customer) {
		this.customer = customer;
	}

	public List<Engineers> getEngineers() {
		return engineers;
	}

	public void setEngineers(List<Engineers> engineers) {
		this.engineers = engineers;
	}
	
	
	
}
