package com.telecom;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.telecom.dao.UserRepository;

import com.telecom.model.User;
import com.telecom.service.UserService;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
public class User_Test {

	@MockBean
	private UserRepository userRepository;
	
	@Autowired
	private UserService userService;
	
	@Test
	public void getUserTest()
	{
		when(userRepository.findAll()).thenReturn(Stream
				.of(new User(1,"Rahul","1234","Customer"),new User(1,"Ram","rm@123","manager"))
				.collect(Collectors.toList()));
		assertEquals(2, userService.findAllUsers().size());
	}
	
	@Test
	public void getUserByUserNameTest()
	{
		String name = "Rahul";
		when(userRepository.findByUserName(name))
				.thenReturn((User) Stream.of(new User(1,"Rahul","1234","Customer"))
						.collect(Collectors.toList()));
		assertEquals(1, userService.findByUserName(name));
	}
	
	@Test
	public void saveUserTest()
	{
		User user=new User(1,"Rahul","1234","Customer");
		when(userRepository.save(user)).thenReturn(user);
		assertEquals(user,userService.saveUser(user) );
	}
	
	@Test
	public void updateUserTest()
	{
		User user=new User(1,"Rahul","1234","Customer");
		when(userRepository.save(user)).thenReturn(user);
		assertEquals(user,userService.updateUser(1, user) );
	}
	
	@Test
	public void deleteUserTest()
	{
		User user=new User(1,"Rahul","1234","Customer");
		when(userRepository.save(user)).thenReturn(user);
		userService.deleteUser(1);
		verify(userRepository, times(1)).deleteById(1);
	}
}
